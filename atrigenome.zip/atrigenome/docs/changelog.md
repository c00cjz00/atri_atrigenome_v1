Version 3.1 Change Log
----------------------

- User management
  - Banning / deleting active users
  - Assigning roles to users
- Role / Permission management
- PSR-4 autoloading & namespaces
- CSRF protection
- Restructured admin pages
  - Added Datatables
- Restructured external asset loading
- Restructured classes into more logical units
- Various bugfixes
- Legacy migration tool
