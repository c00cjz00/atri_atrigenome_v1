### About these scripts

This is a collection of scripts written over the years to solve specific
problems. Some of them are well tested, others not so well. As they have been
written over a long period of time, the style and quality vary.

### Use at your own risk

These programs are provided as is, without any implied garanty of usefulness.

### Licensing

Read the LICENSE file for information about the license affecting these files

### Star history for some of my projects
## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=enormandeau/Scripts,enormandeau/stacks_workflow,enormandeau/gawn,enormandeau/barque,enormandeau/mapcomp,enormandeau/ncbi_blast_tutorial,enormandeau/meditation-timer&type=Date)](https://star-history.com/#enormandeau/Scripts&enormandeau/stacks_workflow&enormandeau/gawn&enormandeau/barque&enormandeau/mapcomp&enormandeau/ncbi_blast_tutorial&enormandeau/meditation-timer&Date)
