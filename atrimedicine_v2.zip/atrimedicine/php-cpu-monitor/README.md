# PHP CPU Monitor

This is a web application created to show CPU and RAM usage graphs dynamically in a web browser. It uses PHP and JQuery and runs on Linux (and potentially Unix) servers. Unfortunately Windows is not supported and never will be under my code-base.

Version 1.0 should work perfectly fine on any Linux system with no special features enabled. In fact a cool feature of it is that it will even work on shared hosting so you can see how loaded the web space you are paying for is!

Original author: Steve Stone

##TODO

- Change the charts to use <http://smoothiecharts.org/>
