#### configure
1. login/dbconf.php

2. elFinder/php/connector.minimal.php

3. upload atri.sql to atri db
Edit table app_config
base_dir=?
base_url=?

4. SMTP
smtp.gmail.com
nchcmail@gmail.com
ozvjyrbhulfuqxhj
