-- MySQL dump 10.13  Distrib 8.0.34, for Linux (x86_64)
--
-- Host: localhost    Database: atrimedicine
-- ------------------------------------------------------
-- Server version	8.0.34-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_config`
--

DROP TABLE IF EXISTS `app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_config` (
  `setting` char(26) NOT NULL,
  `value` varchar(12000) NOT NULL,
  `sortorder` int DEFAULT NULL,
  `category` varchar(25) NOT NULL,
  `type` varchar(15) NOT NULL,
  `description` varchar(140) DEFAULT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`setting`),
  UNIQUE KEY `setting_UNIQUE` (`setting`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_config`
--

LOCK TABLES `app_config` WRITE;
/*!40000 ALTER TABLE `app_config` DISABLE KEYS */;
INSERT INTO `app_config` VALUES ('active_email','Your new account is now active! Click this link to log in!',27,'Messages','text','Email message when account is verified',1),('active_msg','Your account has been verified!',26,'Messages','text','Display message when account is verified',1),('admin_email','summerhill001@gmail.com',31,'Website','text','Site administrator email address',1),('admin_verify','true',21,'Security','boolean','Require admin verification',1),('avatar_dir','/user/avatars',6,'Website','text','Directory where user avatars should be stored inside of base site directory. Do not include base_dir path.',1),('base_dir','/var/www/html/atrigenome',2,'Website','hidden','Base directory of website in filesystem. \"C:\\...\" in windows, \"/...\" in unix systems',1),('base_url','https://atri.biobank.org.tw',3,'Website','url','Base URL of website. Example: \"http://sitename.com\"',1),('cookie_expire_seconds','2592000',19,'Security','number','Cookie expiration (in seconds)',1),('curl_enabled','true',29,'Website','boolean','Enable curl for various processes such as background email sending',1),('email_working','true',30,'Mailer','hidden','Indicates if email settings are correct and can connect to a mail server',1),('from_email','nchcmail@gmail.com',13,'Mailer','email','From email address. Should typically be the same as \"mail_user\" email.',1),('from_name','ARI Genome Portal',14,'Mailer','text','Name that shows up in \"from\" field of emails',1),('htmlhead','<!DOCTYPE html><html lang=\'en\'><head><meta charset=\'utf-8\'><meta name=\'viewport\' content-width=\'device-width\', initial-scale=\'1\', shrink-to-fit=\'no\'>',4,'Website','textarea','Main HTML header of website (without login-specific includes and script tags). Do not close <html> tag! Will break application functionality',1),('jwt_secret','php-login',20,'Security','text','Secret for JWT for tokens (Can be anything)',1),('login_timeout','300',18,'Security','number','Cooloff time for too many failed logins (in seconds)',1),('mail_port','587',12,'Mailer','number','Mail port. Common settings are 465 for ssl, 587 for tls, 25 for other',1),('mail_pw','ozvjyrbhulfuqxhj',10,'Mailer','password','Email password to authenticate mailer',1),('mail_security','tls',11,'Mailer','text','Mail security type. Possible values are \"ssl\", \"tls\" or leave blank',1),('mail_server','smtp.gmail.com',8,'Mailer','text','Mail server address. Example: \"smtp.email.com\"',1),('mail_server_type','smtp',7,'Mailer','text','Type of email server. SMTP is most typical. Other server types untested.',1),('mail_user','nchcmail@gmail.com',9,'Mailer','email','Email user',1),('mainlogo','',5,'Website','url','URL of main site logo. Example \"http://sitename.com/logo.jpg\"',1),('max_attempts','5',17,'Security','number','Maximum login attempts',1),('password_min_length','6',16,'Security','number','Minimum password length if \"password_policy_enforce\" is set to true',1),('password_policy_enforce','true',15,'Security','boolean','Require a mixture of upper and lowercase letters and minimum password length (set by \"password_min_length\")',1),('reset_email','Click the link below to reset your password',28,'Messages','text','Email message when user wants to reset their password',1),('signup_requires_admin','Thank you for signing up! Before you can login, your account needs to be activated by an administrator.',23,'Messages','text','Message displayed when user signs up, but requires admin approval',1),('signup_thanks','Thank you for signing up! You will receive an email shortly confirming the verification of your account.',22,'Messages','text','Message displayed when user signs up and can verify themselves via email',1),('site_name','ATRI GENOME PORTAL',1,'Website','text','Website name',1),('timezone','Asia/Taipei',32,'Website','timezone','Server time zone',1),('token_validity','24',33,'Security','number','Token validity in Hours (default 24 hours)',1),('verify_email_admin','Thank you for signing up! Your account will be reviewed by an admin shortly',24,'Messages','text','Email message when account requires admin verification',1),('verify_email_noadmin','Click this link to verify your new account!',25,'Messages','text','Email message when user can verify themselves',1);
/*!40000 ALTER TABLE `app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cookies`
--

DROP TABLE IF EXISTS `cookies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cookies` (
  `cookieid` char(23) NOT NULL,
  `userid` char(23) NOT NULL,
  `tokenid` char(25) NOT NULL,
  `expired` tinyint(1) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`userid`),
  CONSTRAINT `userid` FOREIGN KEY (`userid`) REFERENCES `members` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cookies`
--

LOCK TABLES `cookies` WRITE;
/*!40000 ALTER TABLE `cookies` DISABLE KEYS */;
/*!40000 ALTER TABLE `cookies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deleted_members`
--

DROP TABLE IF EXISTS `deleted_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deleted_members` (
  `id` char(23) NOT NULL,
  `username` varchar(65) NOT NULL DEFAULT '',
  `password` varchar(65) NOT NULL DEFAULT '',
  `email` varchar(65) NOT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `mod_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deleted_members`
--

LOCK TABLES `deleted_members` WRITE;
/*!40000 ALTER TABLE `deleted_members` DISABLE KEYS */;
INSERT INTO `deleted_members` VALUES ('1088192820650a575ca15aa','peter','$2y$10$uTkV/Fh5rg5va0h1zs5NNeIyyVZ.18UfbN4RL5xaFoQI8tmIXY7.a','summerhill.001@gmail.com',1,0,'2023-09-21 04:08:49'),('1458022030650939a829e14','hcf','$2y$10$EX66IyCKzRBd3zaQJiS4teZwPoqnTPzsRvGl9hnoXscNKdmh6txD.','summerhill00.1@gmail.com',1,0,'2023-09-21 04:08:49'),('1992002466650a528c1554e','allen','$2y$10$/Iow8khl1q0Sfpb6kYeuv.3OctG2pZ8oRYJkOrP8WWrBEiINbJ2FC','0203126@narlabs.org.tw',1,0,'2023-09-20 02:23:33');
/*!40000 ALTER TABLE `deleted_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(65) DEFAULT NULL,
  `IP` varchar(20) NOT NULL,
  `Attempts` int NOT NULL,
  `LastLogin` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES (25,'c00cjz00','203.145.221.208',1,'2023-09-18 23:54:48'),(27,'hcf','203.145.221.208',2,'2023-09-19 19:45:02'),(28,'peter','203.145.221.208',1,'2023-09-20 10:24:30'),(29,'c00cjz00','140.110.35.81',1,'2023-09-20 11:11:35'),(30,'peter','140.110.35.81',1,'2023-09-20 11:12:06'),(31,' hcf','61.216.111.182',3,'2023-09-21 08:36:46'),(32,'hcf','61.216.111.182',1,'2023-09-21 08:37:11');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_log`
--

DROP TABLE IF EXISTS `mail_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mail_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL DEFAULT 'generic',
  `status` varchar(45) DEFAULT NULL,
  `recipient` varchar(5000) DEFAULT NULL,
  `response` mediumtext NOT NULL,
  `isread` tinyint(1) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_log`
--

LOCK TABLES `mail_log` WRITE;
/*!40000 ALTER TABLE `mail_log` DISABLE KEYS */;
INSERT INTO `mail_log` VALUES (54,'Verify','Success','summerhill.001@gmail.com','Mail sent successfully to: summerhill.001@gmail.com',0,'2023-09-19 06:03:23'),(55,'Password Reset','Success','summerhill00.1@gmail.com','Mail sent successfully to: summerhill00.1@gmail.com',0,'2023-09-19 06:23:59'),(56,'Verify','Success','0203126@narlabs.org.tw','Mail sent successfully to: 0203126@narlabs.org.tw',0,'2023-09-20 02:01:51'),(57,'Active','Success','0203126@narlabs.org.tw','Mail sent successfully to: 0203126@narlabs.org.tw',0,'2023-09-20 02:16:44'),(58,'Verify','Success','summerhill.001@gmail.com','Mail sent successfully to: summerhill.001@gmail.com',0,'2023-09-20 02:22:23'),(59,'Active','Success','summerhill.001@gmail.com','Mail sent successfully to: summerhill.001@gmail.com',0,'2023-09-20 02:23:17');
/*!40000 ALTER TABLE `mail_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_info`
--

DROP TABLE IF EXISTS `member_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_info` (
  `userid` char(23) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(55) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address1` varchar(45) DEFAULT NULL,
  `address2` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `bio` varchar(20000) DEFAULT NULL,
  `userimage` varchar(255) DEFAULT NULL,
  UNIQUE KEY `userid_UNIQUE` (`userid`),
  KEY `fk_userid_idx` (`userid`),
  CONSTRAINT `fk_userid` FOREIGN KEY (`userid`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_info`
--

LOCK TABLES `member_info` WRITE;
/*!40000 ALTER TABLE `member_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_jail`
--

DROP TABLE IF EXISTS `member_jail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_jail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` char(23) NOT NULL,
  `banned_hours` float NOT NULL DEFAULT '24',
  `reason` varchar(2000) DEFAULT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_UNIQUE` (`user_id`),
  KEY `fk_userid_idx` (`user_id`),
  CONSTRAINT `fk_userid_jail` FOREIGN KEY (`user_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_jail`
--

LOCK TABLES `member_jail` WRITE;
/*!40000 ALTER TABLE `member_jail` DISABLE KEYS */;
/*!40000 ALTER TABLE `member_jail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_roles`
--

DROP TABLE IF EXISTS `member_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `member_id` char(23) NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_unique_idx` (`member_id`,`role_id`),
  KEY `member_id_idx` (`member_id`),
  KEY `fk_role_id_idx` (`role_id`),
  CONSTRAINT `fk_member_id` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_roles`
--

LOCK TABLES `member_roles` WRITE;
/*!40000 ALTER TABLE `member_roles` DISABLE KEYS */;
INSERT INTO `member_roles` VALUES (1,'1468427746650870ba108e7',1);
/*!40000 ALTER TABLE `member_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `at_least_one_superadmin_assigned` BEFORE DELETE ON `member_roles` FOR EACH ROW BEGIN
			IF ((old.role_id = 1)) && (SELECT COUNT(id) from `member_roles` where role_id = 1) <= 1 THEN
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'There must be at least one Superadmin assigned';
		END IF;
	END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` char(23) NOT NULL,
  `username` varchar(65) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(65) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `mod_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES ('1468427746650870ba108e7','atri','$2y$10$EX66IyCKzRBd3zaQJiS4teZwPoqnTPzsRvGl9hnoXscNKdmh6txD.','summerhill001@gmail.com',1,0,'2023-09-18 15:54:37');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `assign_default_role` AFTER INSERT ON `members` FOR EACH ROW BEGIN
	SET @default_role = (SELECT ID FROM `roles` WHERE `default_role` = 1 LIMIT 1);
    INSERT INTO `member_roles` (`member_id`, `role_id`) VALUES (NEW.id, @default_role);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `prevent_deletion_of_superadmin` BEFORE DELETE ON `members` FOR EACH ROW BEGIN
  	IF
    (SELECT count(m.id)
  	FROM `members` m
  	INNER JOIN `member_roles` mr on mr.member_id = m.id
  	INNER JOIN `roles` r on mr.role_id = r.id
  	WHERE
  	 m.verified = 1
  	AND m.banned = 0
  	AND r.name = 'Superadmin'
      AND m.id = OLD.id) > 0
    THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot delete superadmin user';
    END IF;
  END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `move_to_deleted_members` AFTER DELETE ON `members` FOR EACH ROW BEGIN
      DELETE FROM deleted_members WHERE deleted_members.id = OLD.id;
      INSERT INTO deleted_members ( id, username, password, email, verified) VALUES ( OLD.id, OLD.username, OLD.password, OLD.email, OLD.verified );
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `category` varchar(50) NOT NULL DEFAULT 'General',
  `required` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'Verify Users','Administration permission allowing for the verification of new users','Users',1),(2,'Delete Unverified Users','Administration permission allowing the deletion of unverified users','Users',1),(3,'Ban Users','Moderation permission allowing the banning of users','Users',1),(4,'Assign Roles to Users','Administration permission allowing the assignment of roles to users','Users',1),(5,'Assign Users to Roles','Administration permission allowing the assignment of users to roles','Roles',1),(6,'Create Roles','Administration permission allowing for the creation of new roles','Roles',1),(7,'Delete Roles','Administration permission allowing for the deletion of roles','Roles',1),(8,'Create Permissions','Administration permission allowing for the creation of new permissions','Permissions',1),(9,'Delete Permissions','Administration permission allowing for the deletion of permissions','Permissions',1),(10,'Assign Permissions to Roles','Administration permission allowing the assignment of permissions to roles','Roles',1),(11,'Edit Site Config','Administration permission allowing the editing of core site configuration (dangerous)','Administration',1),(12,'View Permissions','Administration permission allowing the viewing of all permissions','Permissions',1),(13,'View Roles','Administration permission allowing for the viewing of all roles','Roles',1),(14,'View Users','Administration permission allowing for the viewing of all users','Users',1),(15,'Delete Users','Administration permission allowing for the deletion of users','Users',1);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `prevent_deletion_of_required_perms` BEFORE DELETE ON `permissions` FOR EACH ROW BEGIN
    IF OLD.required = 1 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot delete required permissions';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `pipelineJob`
--

DROP TABLE IF EXISTS `pipelineJob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pipelineJob` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '編號',
  `status` varchar(16) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '派送狀態',
  `timeID` varchar(16) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '派送時間',
  `account` varchar(64) NOT NULL COMMENT '派送帳號',
  `expNum` varchar(64) NOT NULL COMMENT '實驗編號',
  `pipeline` varchar(16) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '工作派送代號',
  `information` text NOT NULL COMMENT '輸入資料',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pipelineJob`
--

LOCK TABLES `pipelineJob` WRITE;
/*!40000 ALTER TABLE `pipelineJob` DISABLE KEYS */;
INSERT INTO `pipelineJob` VALUES (1,'1','230920062245','hcf','A01_230920062245','1a','{\"expNum\":\"A01\",\"srrNum\":\"SRR12362016\"}'),(2,'1','230920062245','hcf','A01_230920062245','1a','{\"expNum\":\"A01\",\"srrNum\":\"SRR12362017\"}'),(3,'1','230920062325','hcf','A02_230920062325','1b','{\"expNum\":\"A02\",\"SeqDate\":\"2023-09-21\",\"RunID\":\"A02\",\"Organism\":\"E. coli\",\"LibrarySource\":\"whole genome\",\"Platform\":\"illumina MiSeq\",\"LibraryLayout\":\"Pair-End\",\"InsertSize\":\"2x150\",\"srrNum\":\"PUBLIC/SRR12362016_R1.fastq.gz:PUBLIC/SRR12362016_R2.fastq.gz\"}'),(4,'1','230920062325','hcf','A02_230920062325','1b','{\"expNum\":\"A02\",\"SeqDate\":\"2023-09-21\",\"RunID\":\"A02\",\"Organism\":\"E. coli\",\"LibrarySource\":\"whole genome\",\"Platform\":\"illumina MiSeq\",\"LibraryLayout\":\"Pair-End\",\"InsertSize\":\"2x150\",\"srrNum\":\"PUBLIC/SRR12362017_R1.fastq.gz:PUBLIC/SRR12362017_R2.fastq.gz\"}'),(5,'1','230920104906','peter','A001_230920104906','1a','{\"expNum\":\"A001\",\"srrNum\":\"SRR12362016\"}'),(6,'1','230920104906','peter','A001_230920104906','1a','{\"expNum\":\"A001\",\"srrNum\":\"SRR12362017\"}'),(7,'1','230920104940','peter','A002_230920104940','1b','{\"expNum\":\"A002\",\"SeqDate\":\"2023-09-29\",\"RunID\":\"A08\",\"Organism\":\"E. coli\",\"LibrarySource\":\"whole genome\",\"Platform\":\"illumina MiSeq\",\"LibraryLayout\":\"Pair-End\",\"InsertSize\":\"2x150\",\"srrNum\":\"PUBLIC/SRR12362016_R1.fastq.gz:PUBLIC/SRR12362016_R2.fastq.gz\"}'),(8,'1','230920104940','peter','A002_230920104940','1b','{\"expNum\":\"A002\",\"SeqDate\":\"2023-09-29\",\"RunID\":\"A08\",\"Organism\":\"E. coli\",\"LibrarySource\":\"whole genome\",\"Platform\":\"illumina MiSeq\",\"LibraryLayout\":\"Pair-End\",\"InsertSize\":\"2x150\",\"srrNum\":\"PUBLIC/SRR12362017_R1.fastq.gz:PUBLIC/SRR12362017_R2.fastq.gz\"}');
/*!40000 ALTER TABLE `pipelineJob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Role_Id_idx` (`role_id`),
  KEY `fk_Permission_Id_idx` (`permission_id`),
  CONSTRAINT `fk_Permission_Id` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Role_Id_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,7),(8,1,8),(9,1,9),(10,1,10),(11,1,11),(12,1,12),(13,1,13),(14,1,14),(15,1,15),(16,2,1),(17,2,2),(18,2,3),(19,2,4),(20,2,5),(21,2,12),(22,2,13),(23,2,14),(24,2,15);
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `default_role` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  UNIQUE KEY `default_role_UNIQUE` (`default_role`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Superadmin','Master administrator of site',1,NULL),(2,'Admin','Site administrator',1,NULL),(3,'Standard User','Default site role for standard users',1,1);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `prevent_deletion_of_required_roles` BEFORE DELETE ON `roles` FOR EACH ROW BEGIN
      IF OLD.required = 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot delete required roles';
      END IF;
  END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `tokenid` char(25) NOT NULL,
  `userid` char(23) NOT NULL,
  `expired` tinyint(1) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tokenid`),
  UNIQUE KEY `tokenid_UNIQUE` (`tokenid`),
  UNIQUE KEY `userid_UNIQUE` (`userid`),
  CONSTRAINT `userid_t` FOREIGN KEY (`userid`) REFERENCES `members` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-21 12:11:01
