#### configure
1. login/dbconf.php

2. elFinder/php/connector.minimal.php

3. atrimedicine.sql
Edit table app_config
base_dir=?
base_url=?
atri/atri@1234QWER
